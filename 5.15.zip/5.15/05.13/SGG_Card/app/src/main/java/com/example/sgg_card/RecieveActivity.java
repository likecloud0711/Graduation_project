package com.example.sgg_card;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.SearchManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.MifareUltralight;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.concurrent.ExecutionException;

public class RecieveActivity extends AppCompatActivity {

    NfcAdapter nfcAdapter;
    PendingIntent pendingIntent;
    final static String TAG= "nfc_test";

    TextView show_name,show_company,show_position,show_address,show_phone,show_email, address;
    ImageButton save, go_main;
    LinearLayout shoshow;
    ImageView show_img;
    TextView signup_nfc;
    String[] getData;
    String beacon;
   // public int a;
    public String key;
    Bitmap bitmap;
    Thread uThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recieve2);

        setTitle("상대방명함 받아오기");
        nfcAdapter= NfcAdapter.getDefaultAdapter(this);

        if (nfcAdapter==null){
            Toast.makeText(this, "NO NFC", Toast.LENGTH_SHORT).show();
            finish();
        }
        pendingIntent= PendingIntent.getActivity(this, 0,
                new Intent(this, this.getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),0);

        show_img=findViewById(R.id.show_img);
        show_name= findViewById(R.id.show_name);
        show_company= findViewById(R.id.show_company);
        show_email= findViewById(R.id.show_email);
        show_phone= findViewById(R.id.show_phone);
        show_address= findViewById(R.id.show_address);
        show_position= findViewById(R.id.show_position);
        save= findViewById(R.id.save);
        signup_nfc= findViewById(R.id.signup_nfc);
        shoshow=findViewById(R.id.shoshow);
        go_main= findViewById(R.id.go_main);
        address= findViewById(R.id.address);

        Intent keyintent=getIntent();
        key=keyintent.getStringExtra("key");


        showDialognfc(); //nfc 태그 alert창 띄우기

        uThread = new Thread() {
            @Override
            public void run(){
                try{
                    String str;

                    URL url = new URL("http://192.168.0.2:8081/DbConn/Android/image/"+getData[7]);
                    HttpURLConnection conn = (HttpURLConnection)url.openConnection();

                    conn.setDoInput(true); //Server 통신에서 입력 가능한 상태로 만듦

                    conn.connect(); //연결된 곳에 접속할 때 (connect() 호출해야 실제 통신 가능함)

                    InputStream is = conn.getInputStream(); //inputStream 값 가져오기
                    bitmap = BitmapFactory.decodeStream(is); // Bitmap으로 반환
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        };

//--상대방명함 저장부분  mykey(내 아이디),상대방 nfc,name ,company
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               //확인다이얼로그창
                AlertDialog.Builder saveBuilder=new AlertDialog.Builder(RecieveActivity.this)
                        .setTitle("저장하나요?")
                        .setMessage("")
                        .setNegativeButton("아니요", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                        .setPositiveButton("네", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                try {

                                    String result;

                                    String my_key= key;//내아이디 가져오기
                                    String nfc= signup_nfc.getText().toString();
                                    String name= show_name.getText().toString();
                                    String company= show_company.getText().toString();
                                    String position= show_position.getText().toString();

                                    String type= "p";


                                    //String key; //데베에 하나더 추가X

                                    Mycard save_server= new Mycard();
                                    result= save_server.execute(my_key,nfc, name, company, position,type, beacon).get();

                                    switch (result) {
                                        case "r":
                                            Toast.makeText(getApplicationContext(), "이미있는 명함입니다", Toast.LENGTH_SHORT).show();
                                            signup_nfc.setText("");
                                            break;
                                        case "s":
                                            Toast.makeText(getApplicationContext(), "저장을 성공했습니다", Toast.LENGTH_SHORT).show();
                                            save.setVisibility(View.GONE);
//                                            Intent intent= new Intent(getApplicationContext(),ShowcardActivity.class); //->저장된거 보는걸로 넘어가기(엑티비티생성해야함)
//                                            //정보들 보내기
//                                            intent.putExtra("nfc",nfc);
//                                            intent.putExtra("key",key);
//
//                                            startActivity(intent);
//                                            break;
                                    }
                                } catch (ExecutionException e) {
                                    e.printStackTrace();
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }

                            }
                        });

                AlertDialog msgDlg=saveBuilder.create();
                msgDlg.show();

            }
        });
        go_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back= new Intent(getApplicationContext(), MainActivity2.class);
                back.putExtra("key", key);
                startActivity(back);
            }
        });

    }

    public void showDialognfc() {
        AlertDialog.Builder msgBuilder=new AlertDialog.Builder(RecieveActivity.this)
                .setTitle("제목?")
                .setMessage("nfc태그해주세요")
                .setNegativeButton("닫기", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });

        AlertDialog msgDlg=msgBuilder.create();
        msgDlg.show();

        //msgDlg.dismiss();
        //태그하면 창없애기기
    }


    //NFC설정
    @Override
    protected void onResume() {
        super.onResume();
        assert  nfcAdapter != null;

        nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(this);
        }
    }
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        resolveIntent(intent);
    }

    private void resolveIntent(Intent intent) {
        String action= intent.getAction();

        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_TECH_DISCOVERED.equals(action) ||
                NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action))
        {
            Tag tag= (Tag) intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            assert tag != null;

            byte[] ID= tag.getId();
            MifareUltralight mifareUlTag = MifareUltralight.get(tag);
            readTag(mifareUlTag);



            signup_nfc.setText(toReversedHex(ID));
            go();
            shoshow.setVisibility(View.VISIBLE);

        }

    }
//정보가져오기
    private void go() {
        try {
            String result;
            String nfc = signup_nfc.getText().toString();
            String type = "u";

            Receive_server2 task = new Receive_server2();
            result = task.execute(nfc, type).get();
            getData= result.split("/");

            if (getData[1].equals("0")) {
                address.setText("WEB : ");
                show_address.setAutoLinkMask(Linkify.WEB_URLS);
                show_company.setVisibility(View.GONE);
            }

            show_name.setText(getData[0]);
            show_company.setText(getData[1]);
            show_position.setText(getData[2]);
            show_phone.setText(getData[3]);
            show_email.setText(getData[4]);
            show_address.setText(getData[5]);
            beacon= getData[6];

            uThread.start();
            uThread.join();
            show_img.setImageBitmap(bitmap);


        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private String toReversedHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bytes.length; ++i) {
            if (i > 0) {
                sb.append(" ");
            }
            int b = bytes[i] & 0xff;
            if (b < 0x10)
                sb.append('0');
            sb.append(Integer.toHexString(b));
        }
        return sb.toString();
    }
    public String readTag(MifareUltralight mifareUlTag) {

        try {
            mifareUlTag.connect();
            byte[] payload = mifareUlTag.readPages(4);
            return new String(payload, Charset.forName("US-ASCII"));
        } catch (IOException e) {
            Log.e(TAG, "IOException while reading MifareUltralight message...", e);
        } finally {
            if (mifareUlTag != null) {
                try {

                    mifareUlTag.close();
                }
                catch (IOException e) {
                    Log.e(TAG, "Error closing tag...", e);
                }
            }
        }
        return null;
    }

}
