package com.example.sgg_card;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;



public class SplashActivity<GlideDrawableImageViewTarget> extends AppCompatActivity {
    Animation anim_FadeIn;
    Animation anim_FadeOut;
    Animation anim_FadeOut1;
    ConstraintLayout constraintLayout;
    ImageView icon1, icon2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        constraintLayout=findViewById(R.id.constraintLayout);
        icon1=findViewById(R.id.icon1);
        icon2=findViewById(R.id.icon2);


        anim_FadeIn= AnimationUtils.loadAnimation(this,R.anim.anim_splash_fadein);
        anim_FadeOut= AnimationUtils.loadAnimation(this,R.anim.anim_splash_icon);
        anim_FadeOut1 = AnimationUtils.loadAnimation(this, R.anim.fadeout);

        anim_FadeIn.setAnimationListener(new Animation.AnimationListener(){

                                             @Override
                                             public void onAnimationStart(Animation animation) {

                                             }

                                             @Override
                                             public void onAnimationEnd(Animation animation) {
                                                startActivity(new Intent(SplashActivity.this,First.class));
                                             }

                                             @Override
                                             public void onAnimationRepeat(Animation animation) {

                                             }
                                         });

                        icon1.startAnimation(anim_FadeOut);
                        icon2.startAnimation(anim_FadeIn);


    }



}