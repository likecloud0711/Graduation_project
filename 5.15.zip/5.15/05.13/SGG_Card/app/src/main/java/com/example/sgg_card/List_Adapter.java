package com.example.sgg_card;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

//가로로 시도해볼거

public class List_Adapter extends RecyclerView.Adapter<List_Adapter.MyViewHolder> {
    private static final String TAG= "ListAdpater";
    private List<Save_user> items= new ArrayList<>();

    public void addItem(Save_user save_user) {
        items.add(save_user);
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater= LayoutInflater.from(parent.getContext());
        View view= inflater.inflate(R.layout.list_layout, parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Save_user save_user= items.get(position);
        holder.setItem(save_user);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView name, company, position;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name= itemView.findViewById(R.id.name);
            company= itemView.findViewById(R.id.company);
            position= itemView.findViewById(R.id.position);

        }
        public void setItem(Save_user save_user){
//            name.setText(save_user.());
//            imageResource.setImageResource(movie.getImgResource());
        }
    }
}
