package com.example.sgg_card;

public class Save_user {
        public String name="";
        public String company="";
        public String position="";
}
