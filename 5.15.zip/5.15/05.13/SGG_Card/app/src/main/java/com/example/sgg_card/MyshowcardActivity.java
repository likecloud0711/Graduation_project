package com.example.sgg_card;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutionException;

public class MyshowcardActivity extends AppCompatActivity {

    Button editbtn, close, goweb;
    ImageView show_img,btn1,btn2,btn3, my;;
    TextView signup_nfc,show_company,show_name,show_position,show_address,show_phone,show_email, address;
    String key, nfc, data;
    String[] getData;
    Bitmap bitmap;
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myshowcard);

        show_img = findViewById(R.id.show_img);
        signup_nfc = findViewById(R.id.signup_nfc);
        show_company = findViewById(R.id.show_company);
        show_name = findViewById(R.id.show_name);
        show_position = findViewById(R.id.show_position);
        show_address = findViewById(R.id.show_address);
        show_phone = findViewById(R.id.show_phone);
        show_email = findViewById(R.id.show_email);
        editbtn = findViewById(R.id.editbtn);
        address= findViewById(R.id.address);
        show_email.setAutoLinkMask(Linkify.EMAIL_ADDRESSES);
        goweb= findViewById(R.id.goweb);

        btn1=findViewById(R.id.btn1);
        //btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        my= findViewById(R.id.my);

        Intent intent = getIntent();
        nfc = intent.getStringExtra("nfc");
        key= intent.getStringExtra("key");

        signup_nfc.setText(nfc);

        Thread uThread = new Thread() {
            @Override
            public void run(){
                try{
                    String str;

                    URL url = new URL("http://192.168.0.2:8081/DbConn/Android/image/"+getData[7]);
                    HttpURLConnection conn = (HttpURLConnection)url.openConnection();

                    conn.setDoInput(true); //Server 통신에서 입력 가능한 상태로 만듦

                    conn.connect(); //연결된 곳에 접속할 때 (connect() 호출해야 실제 통신 가능함)

                    InputStream is = conn.getInputStream(); //inputStream 값 가져오기
                    bitmap = BitmapFactory.decodeStream(is); // Bitmap으로 반환
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        };

        try {
            String result;
            String nfc = signup_nfc.getText().toString();

            String type = "u";

            Receive_server2 task = new Receive_server2();
            result = task.execute(nfc, type).get();
            getData = result.split("/");

            if (getData[1].equals("0")) {
//                address.setText("WEB:   ");
//                show_address.setAutoLinkMask(Linkify.WEB_URLS);
                goweb.setVisibility(View.VISIBLE);
                address.setVisibility(View.GONE);
                show_company.setVisibility(View.GONE);
            }

            show_name.setText(getData[0]);
            show_company.setText(getData[1]);
            show_position.setText(getData[2]);
            show_phone.setText(getData[3]);
            show_email.setText(getData[4]);
            show_address.setText(getData[5]);

            uThread.start();
            uThread.join();
            show_img.setImageBitmap(bitmap);

        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }

        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goinfo = new Intent(getApplicationContext(), UpdateActivity.class);
                goinfo.putExtra("nfc", nfc);
                goinfo.putExtra("key", key);
//                goinfo.putExtra("name", getData[0]);
//                goinfo.putExtra("company", getData[1]);
//                goinfo.putExtra("position", getData[2]);
//                goinfo.putExtra("phone", getData[3]);
//                goinfo.putExtra("email", getData[4]);
//                goinfo.putExtra("address", getData[5]);

                startActivity(goinfo);
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back= new Intent(getApplicationContext(), MainActivity2.class);
                back.putExtra("key", key);
                startActivity(back);
            }
        });
        goweb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    webgo receive = new webgo();
                    data = receive.execute(key, "mp").get();
                } catch (ExecutionException | InterruptedException e) {
                    e.printStackTrace();
                }
                if (data.equals("a")) {
                    Intent intent= new Intent(Intent.ACTION_VIEW, Uri.parse("http://192.168.0.2:8081/webea/index_form.jsp"));
                    startActivity(intent);
                }
                else {

                }
            }
        });
    }
    //하단버튼3개
    public void onclick(View v){
        switch (v.getId()){
            case R.id.btn1 : //상대보기화면으로 넘어가기
                Intent intent= new Intent(getApplicationContext(), RecieveActivity.class);
                intent.putExtra("key",key);
                startActivity(intent);
                break;
//            case R.id.btn2:
//
//                break;

            case R.id.btn3:
                SaveSharedPreference.clearUserId(this);
                Intent intent1= new Intent(getApplicationContext(), First.class);
                startActivity(intent1);
                break;
            case R.id.my:
                try {
                    String type="q";

                    Exisit_server exist =new Exisit_server();
                    result=exist.execute(key,type).get();
                    String[] re= new String[3];
                    re= result.split("/");

                    if (re[0].equals("e")){//내명함
                        String nfc= re[1];

                        Intent intent2=new Intent(this,MyshowcardActivity.class);
                        intent2.putExtra("key",key);
                        intent2.putExtra("nfc", nfc);

                        startActivity(intent2);
                    }
                    else {//명함추가
                        String nfc= re[0];
                        String beacon= re[1];

                        Intent intent3=new Intent(getApplicationContext(),MyCardActivity.class);
                        intent3.putExtra("key", key);
                        intent3.putExtra("nfc", nfc);
                        intent3.putExtra("beacon", beacon);
                        startActivity(intent3);
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

        }
    }

}