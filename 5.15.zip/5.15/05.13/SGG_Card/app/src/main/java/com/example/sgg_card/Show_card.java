package com.example.sgg_card;

import static android.view.View.GONE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class Show_card extends AppCompatActivity {
    String nfc, key, my_key1;
    String[] result;
    String type="c";

    ImageView image;
    TextView name, position, company, address, phone, email, Address;
    ImageButton back,callimg;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_card);

        Intent intent= getIntent();
        nfc= intent.getStringExtra("nfc");
        key= intent.getStringExtra("my_key");
        my_key1=intent.getStringExtra("key");//id값

        image= findViewById(R.id.show_img);
        name= findViewById(R.id.show_name);
        position= findViewById(R.id.show_position);
        company= findViewById(R.id.show_company);
        address= findViewById(R.id.show_address);
        phone= findViewById(R.id.show_phone);
        email= findViewById(R.id.show_email);
        back= findViewById(R.id.back);
        callimg=findViewById(R.id.callimg);
        Address= findViewById(R.id.Address);
        email.setAutoLinkMask(Linkify.EMAIL_ADDRESSES); //이메일 보내기

        getData(nfc);
        //이미지img_path= result[0];
        Thread uThread = new Thread() {
            @Override
            public void run(){
                try{
                    String str;

                    URL url = new URL("http://192.168.0.2:8081/DbConn/Android/image/"+result[0]);
                    HttpURLConnection conn = (HttpURLConnection)url.openConnection();

                    conn.setDoInput(true); //Server 통신에서 입력 가능한 상태로 만듦

                    conn.connect(); //연결된 곳에 접속할 때 (connect() 호출해야 실제 통신 가능함)

                    InputStream is = conn.getInputStream(); //inputStream 값 가져오기

                    bitmap = BitmapFactory.decodeStream(is); // Bitmap으로 반환
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        };

        if (result[3].equals("0")) {
            Address.setText("WEB :  ");
            company.setVisibility(GONE);
            address.setAutoLinkMask(Linkify.WEB_URLS);
        }

        name.setText(result[1]);
        position.setText(result[2]);
        company.setText(result[3]);
        address.setText(result[4]);
        phone.setText(result[5]);
        email.setText(result[6]);

        try {
            uThread.start();
            uThread.join();
            image.setImageBitmap(bitmap);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back= new Intent(getApplicationContext(), MainActivity2.class);
                back.putExtra("key", key);
                setResult(RESULT_OK, back);
                finish();
            }
        });

        //전화걸기
        callimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tt = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + result[5]));
                startActivity(tt);

            }
        });
    }


    public void getData(String nfc) {
        try {
            ListClick_server receive= new ListClick_server();
            String data= receive.execute(nfc, type).get();
            result= data.split("/");

        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }

    }
    //메뉴 상단바 버튼
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu1, menu);
        return true;
    }

    //상단바 클릭코드(내 명함)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.delete_btn:
                //내명함 저장 부분 (만약 정보가 없으면 저장할수있는 폼 /있으면 내명함 보여주기)
                try {
                    String result;
                    String nfc1=nfc; //nfc값
                    String id=my_key1; //id

                    String type="z";

                    delete_server delete =new delete_server();
                    result=delete.execute(id,nfc1,type).get();


                    switch (result) {
                        case "s": //삭제실패
                            Toast.makeText(Show_card.this, "삭제실패스얌.", Toast.LENGTH_SHORT).show();
                            break;
                        case "e": //

//                            Intent intent1=new Intent(this,MyshowcardActivity.class);
//                            intent1.putExtra("nfc",resultnfc);
//                            startActivity(intent1);
                            Toast.makeText(Show_card.this, "삭제성공스얌.", Toast.LENGTH_SHORT).show();
                            Intent main= new Intent(getApplicationContext(), MainActivity2.class);
                            main.putExtra("key", my_key1);
                            startActivity(main);
                            break;
                    }


                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }



                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}