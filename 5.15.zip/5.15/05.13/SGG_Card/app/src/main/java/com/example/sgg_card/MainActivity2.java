package com.example.sgg_card;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.Image;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class MainActivity2 extends AppCompatActivity {

    public static final int REQUEST_CODE = 100;
    public static final int REQUEST_CODE2 = 103;

    ImageView btn1,btn2,btn3, my;
    ListView listView;
    String key, resultnfc;
    String n_type="n";
//    String[] result;
    String A;
    ArrayList<Save_user> userDataView= new ArrayList<>();
    String result;

    List<String> Name= new ArrayList<>();
    List<String> Company= new ArrayList<>();
    List<String> Position= new ArrayList<>();
    List<String> NFC= new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        setTitle("명함 activity");

        btn1=findViewById(R.id.btn1);
        //btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        listView= findViewById(R.id.listview);
        my= findViewById(R.id.my);

        Intent intent= getIntent();
        key= intent.getStringExtra("key");
        getList(key);

        if (A=="s") {
            for (int i=0; i<Name.size(); i++) {
                Save_user userData= new Save_user();
                userData.name= Name.get(i);
                userData.company= Company.get(i);
                userData.position= Position.get(i);

                userDataView.add(userData);
            }
        }
        else {
            Save_user userData= new Save_user();
            userData.name= Name.get(0);
            userData.company= Company.get(0);
            userData.position= Position.get(0);

            userDataView.add(userData);
        }

        ListAdapter adapter= new CustomListView(userDataView);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent show= new Intent(getApplicationContext(), Show_card.class);
                show.putExtra("nfc",NFC.get(i));
                show.putExtra("key",key);//id값
                show.putExtra("my_key",resultnfc);

                startActivityForResult(show, REQUEST_CODE);
            }
        });
    }
    
    //하단버튼3개
    public void onclick(View v){
        switch (v.getId()){
            case R.id.btn1 : //상대보기화면으로 넘어가기
                Intent intent= new Intent(getApplicationContext(), RecieveActivity.class);
                intent.putExtra("key",key);
                startActivity(intent);
                break;
//            case R.id.btn2:
//
//                break;

            case R.id.btn3:
                SaveSharedPreference.clearUserId(this);
                Intent intent1= new Intent(getApplicationContext(), First.class);
                startActivity(intent1);
                break;
            case R.id.my:
                try {
                    String type="q";

                    Exisit_server exist =new Exisit_server();
                    result=exist.execute(key,type).get();
                    String[] re= new String[3];
                    re= result.split("/");

                    if (re[0].equals("e")){//내명함
                        String nfc= re[1];

                        Intent intent2=new Intent(this,MyshowcardActivity.class);
                        intent2.putExtra("key",key);
                        intent2.putExtra("nfc", nfc);

                        startActivity(intent2);
                    }
                    else {//명함추가
                        String nfc= re[0];
                        String beacon= re[1];

                        Intent intent3=new Intent(getApplicationContext(),MyCardActivity.class);
                        intent3.putExtra("key", key);
                        intent3.putExtra("nfc", nfc);
                        intent3.putExtra("beacon", beacon);
                        startActivity(intent3);
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

        }
    }
//리스트
    public void getList(String my_key) {
        String data="";
        try {
            Receive_server receive = new Receive_server();
            data = receive.execute(my_key, n_type).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }
            if (data.equals("a")) {
                A = "n";

                Name.add("저장된 정보 없음");
                Company.add("");
                Position.add("");
                NFC.add("");

            }
            else {
                A = "s";
                String[] result;

                result = data.split("/");

                for (int i = 0; i < result.length; i += 4) {
                    Name.add(result[i]);
                }
                for (int i = 1; i < result.length; i += 4) {
                    if (result[i].equals("0"))
                        Company.add(result[i+1]); //회사대신 직업?이름
                    else
                        Company.add(result[i]);
                }
                for (int i = 2; i < result.length; i += 4) {
                    if (result[i-1].equals("0"))
                        Position.add(""); //웹명함인 경우 비우기
                    else
                        Position.add(result[i]);
                }
                for (int i = 3; i < result.length; i += 4) {
                    NFC.add(result[i]);
                }

            }
    }

    //메뉴 상단바 버튼
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE) {
            if (resultCode != Activity.RESULT_OK) {
                return;
            }
            key = data.getExtras().getString("key");
        }
    }
//상단바 클릭코드
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.action_btn1:
                //내명함 저장 부분 (만약 정보가 없으면 저장할수있는 폼 /있으면 내명함 보여주기)
                try {
                    String type="q";

                    Exisit_server exist =new Exisit_server();
                    result=exist.execute(key,type).get();
                    String[] re= new String[3];
                    re= result.split("/");

                    if (re[0].equals("e")){//내명함
                        String nfc= re[1];

                        Intent intent1=new Intent(this,MyshowcardActivity.class);
                        intent1.putExtra("key",key);
                        intent1.putExtra("nfc", nfc);

                        startActivity(intent1);
                    }
                    else {//명함추가
                        String nfc= re[0];
                        String beacon= re[1];

                        Intent intent=new Intent(getApplicationContext(),MyCardActivity.class);
                        intent.putExtra("key", key);
                        intent.putExtra("nfc", nfc);
                        intent.putExtra("beacon", beacon);
                        startActivity(intent);
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }



                return true;
            case R.id.action_btn2:
                //찾기
                Intent find= new Intent(getApplicationContext(), Find_user.class);
                find.putExtra("key", key);
                startActivity(find);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}