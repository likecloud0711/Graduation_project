package com.example.sgg_card;

import android.view.View;

public interface OnBeaconClicklistener {
    void onItemClick(BeaconListAdapter_f.MyViewHolder holder, View view, int position);
}
